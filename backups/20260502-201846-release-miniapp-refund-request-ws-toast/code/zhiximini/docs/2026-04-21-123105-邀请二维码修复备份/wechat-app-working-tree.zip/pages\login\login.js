const { request } = require('../../utils/request');
const app = getApp();

Page({
  data: {
    agreed: false
  },

  toggleAgreement() {
    this.setData({ agreed: !this.data.agreed });
  },

  onCancel() {
    wx.switchTab({ url: '/pages/index/index' });
  },

  onWechatLogin() {
    if (!this.data.agreed) {
      wx.showToast({ title: '请先阅读并同意用户协议', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '登录中...' });
    
    wx.login({
      success: (res) => {
        if (res.code) {
          // Check for invitation code in local storage
          const inviterId = wx.getStorageSync('inviterId') || null;
          
          request({
            url: '/api/auth/wechat-miniapp/login',
            method: 'POST',
            data: { 
              code: res.code,
              inviterId: inviterId
            }
          }).then(resData => {
            wx.hideLoading();
            const { token, userId, phone, nickname, inviteCode } = resData.data;
            wx.setStorageSync('token', token);
            wx.setStorageSync('userInfo', { userId, phone, nickname, inviteCode });
            
            wx.showToast({ title: '登录成功', icon: 'success' });
            setTimeout(() => {
              wx.switchTab({ url: '/pages/user/user' });
            }, 800);
          }).catch(err => {
            wx.hideLoading();
          });
        } else {
          wx.hideLoading();
          wx.showToast({ title: '登录失败', icon: 'none' });
        }
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '调用微信登录失败', icon: 'none' });
      }
    });
  }
});
