// 邀请码与二维码、邀请记录
Page({
  data: {
    tab: 'code',
    showTabs: true,
    inviteCode: '',
    qrcodeUrl: '', // TODO: 后端生成小程序码
    recordList: [],
  },

  onLoad(options) {
    if (options.tab === 'record') {
      this.setData({ tab: 'record' });
    }
    this.loadCode();
    this.loadRecord();
  },

  switchTab(e) {
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  loadCode() {
    const userInfo = wx.getStorageSync('userInfo');
    this.setData({
      inviteCode: userInfo ? userInfo.inviteCode : '暂未生成',
      qrcodeUrl: '', // TODO: generate backend QR code
    });
  },

  loadRecord() {
    this.setData({ recordList: [] });
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo.userId) return;

    request({
      url: `/api/invites/${userInfo.userId}`,
      method: 'GET'
    }).then(res => {
      const list = res.data || [];
      const mapped = list.map(item => ({
        id: item.id,
        nickName: `用户${item.inviteeId}`,
        bindTime: item.boundAt ? item.boundAt.substring(0, 10) : '',
        hasFirstOrder: !!item.firstPaidAt
      }));
      this.setData({ recordList: mapped });
    });
  },

  copyCode() {
    const code = this.data.inviteCode;
    if (!code) {
      wx.showToast({ title: '暂无邀请码', icon: 'none' });
      return;
    }
    wx.setClipboardData({
      data: code,
      success: () => wx.showToast({ title: '已复制', icon: 'success' }),
    });
  },
});
