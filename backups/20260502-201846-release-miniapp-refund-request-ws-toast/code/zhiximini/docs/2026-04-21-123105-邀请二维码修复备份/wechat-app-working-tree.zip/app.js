// 洗衣液销售小程序 - 应用入口
App({
  globalData: {
    userInfo: null,
    token: null,
    baseUrl: '', // 后端 API 基础地址，正式环境需配置
  },

  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || [];
    logs.unshift(Date.now());
    wx.setStorageSync('logs', logs);

    // 检查登录状态
    const token = wx.getStorageSync('token');
    if (token) {
      this.globalData.token = token;
    }
  },
});
