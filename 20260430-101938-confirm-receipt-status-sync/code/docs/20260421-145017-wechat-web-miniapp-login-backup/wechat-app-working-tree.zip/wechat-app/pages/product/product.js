const { request } = require('../../utils/request.js');
const { normalizeProduct } = require('../../utils/product.js');

Page({
  data: {
    product: null,
    count: 1,
    total: 0,
    loading: true
  },

  onLoad(options) {
    if (options.id) {
      this.productId = options.id;
      this.fetchProductDetail(options.id);
    }
  },

  onShow() {
    if (this._hasLoadedOnce && this.productId) {
      this.fetchProductDetail(this.productId);
    }
    this._hasLoadedOnce = true;
  },

  fetchProductDetail(id) {
    this.setData({ loading: true });
    request({
      url: `/api/products/${id}`,
      method: 'GET'
    })
      .then((res) => {
        const product = normalizeProduct(res.data);
        this.setData({
          product,
          total: product ? (product.price * this.data.count).toFixed(2) : '0.00',
          loading: false
        });
      })
      .catch(() => {
        this.setData({
          product: null,
          total: '0.00',
          loading: false
        });
      });
  },

  minus() {
    let count = this.data.count;
    if (count <= 1) return;
    count -= 1;
    this.updateTotal(count);
  },

  plus() {
    let count = this.data.count;
    count += 1;
    this.updateTotal(count);
  },

  onCountInput(e) {
    let count = parseInt(e.detail.value, 10) || 1;
    if (count < 1) count = 1;
    this.updateTotal(count);
  },

  updateTotal(count) {
    const price = this.data.product ? Number(this.data.product.price) : 0;
    this.setData({
      count,
      total: (count * price).toFixed(2)
    });
  },

  submitOrder() {
    if (!this.data.product) return;
    wx.navigateTo({
      url: `/pages/address-edit/address-edit?productId=${this.data.product.id}&quantity=${this.data.count}`
    });
  }
});
