const { request } = require('../../utils/request');
const config = require('../../utils/config');
const app = getApp();
const TEXTS = {
  agreeFirst: '\u8bf7\u5148\u9605\u8bfb\u5e76\u540c\u610f\u7528\u6237\u534f\u8bae',
  invalidAppId: '\u8bf7\u4f7f\u7528\u771f\u5b9e\u5c0f\u7a0b\u5e8f AppID \u8fd0\u884c',
  localBackendOnDevice: '\u771f\u673a\u65e0\u6cd5\u8bbf\u95ee localhost\uff0c\u8bf7\u5207\u6362\u7ebf\u4e0a\u63a5\u53e3',
  loggingIn: '\u767b\u5f55\u4e2d...',
  loginFailed: '\u767b\u5f55\u5931\u8d25',
  loginSuccess: '\u767b\u5f55\u6210\u529f',
  wxLoginFailed: '\u8c03\u7528\u5fae\u4fe1\u767b\u5f55\u5931\u8d25'
};

Page({
  data: {
    agreed: false
  },

  toggleAgreement() {
    this.setData({ agreed: !this.data.agreed });
  },

  onCancel() {
    wx.switchTab({ url: '/pages/index/index' });
  },

  onWechatLogin() {
    if (!this.data.agreed) {
      wx.showToast({ title: TEXTS.agreeFirst, icon: 'none' });
      return;
    }

    const readyError = this.getBackendReadyError();
    if (readyError) {
      wx.showToast({ title: readyError, icon: 'none' });
      return;
    }

    wx.showLoading({ title: TEXTS.loggingIn });

    Promise.all([this.getWechatLoginCode(), this.getWechatProfile()])
      .then(([code, profile]) => this.submitWechatLogin(code, profile))
      .then((resData) => {
        wx.hideLoading();
        const { token, userId, phone, nickname, inviteCode } = resData.data;
        wx.setStorageSync('token', token);
        wx.setStorageSync('userInfo', {
          userId,
          phone,
          nickname,
          inviteCode,
          avatarUrl: (resData.data && resData.data.avatarUrl) || ''
        });
        wx.removeStorageSync('inviterId');
        app.globalData.inviterId = null;

        wx.showToast({ title: TEXTS.loginSuccess, icon: 'success' });
        setTimeout(() => {
          wx.switchTab({ url: '/pages/user/user' });
        }, 800);
      })
      .catch((error) => {
        wx.hideLoading();
        if (error && error.silent) {
          return;
        }
        const message = this.getErrorMessage(error);
        if (message) {
          wx.showToast({ title: message, icon: 'none' });
        }
      });
  },

  getWechatLoginCode() {
    return new Promise((resolve, reject) => {
      wx.login({
        success: (res) => {
          if (res.code) {
            resolve(res.code);
            return;
          }
          reject(new Error(TEXTS.loginFailed));
        },
        fail: (err) => {
          console.error('wx.login failed', err);
          reject(new Error((err && err.errMsg) || TEXTS.wxLoginFailed));
        }
      });
    });
  },

  getWechatProfile() {
    if (typeof wx.getUserProfile !== 'function') {
      return Promise.resolve({});
    }

    return new Promise((resolve) => {
      wx.getUserProfile({
        desc: '\u7528\u4e8e\u5b8c\u5584\u8d26\u53f7\u8d44\u6599',
        success: (res) => resolve(res.userInfo || {}),
        fail: () => resolve({})
      });
    });
  },

  submitWechatLogin(code, profile) {
    const inviterId = wx.getStorageSync('inviterId') || app.globalData.inviterId || null;
    return request({
      url: '/api/auth/wechat-miniapp/login',
      method: 'POST',
      data: {
        code,
        inviterId,
        nickName: profile.nickName || profile.nickname || '',
        avatarUrl: profile.avatarUrl || ''
      }
    });
  },

  getBackendReadyError() {
    const accountInfo = typeof wx.getAccountInfoSync === 'function' ? wx.getAccountInfoSync() : null;
    const appId = accountInfo && accountInfo.miniProgram && accountInfo.miniProgram.appId;
    if (!appId || String(appId).indexOf('tourist') >= 0) {
      return TEXTS.invalidAppId;
    }

    const baseUrl = app.globalData.baseUrl || config.baseUrl || '';
    const systemInfo = typeof wx.getSystemInfoSync === 'function' ? wx.getSystemInfoSync() : {};
    const platform = String(systemInfo.platform || '').toLowerCase();
    if (/localhost|127\.0\.0\.1/i.test(baseUrl) && platform !== 'devtools') {
      return TEXTS.localBackendOnDevice;
    }
    return '';
  },

  getErrorMessage(error) {
    if (!error) {
      return TEXTS.wxLoginFailed;
    }
    if (typeof error.message === 'string' && error.message.trim()) {
      return error.message.trim();
    }
    if (typeof error.errMsg === 'string' && error.errMsg.trim()) {
      return error.errMsg.trim();
    }
    if (error.data && typeof error.data.message === 'string' && error.data.message.trim()) {
      return error.data.message.trim();
    }
    return TEXTS.wxLoginFailed;
  }
});
