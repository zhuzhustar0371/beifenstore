// 收货地址列表
Page({
  data: {
    list: [], // TODO: 从接口拉取
  },

  onShow() {
    this.loadList();
  },

  loadList() {
    // TODO: 请求地址列表
    this.setData({ list: [] });
  },

  add() {
    wx.navigateTo({ url: '/pages/address-edit/address-edit' });
  },

  edit(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/address-edit/address-edit?id=' + id });
  },

  del(e) {
    wx.showModal({
      title: '提示',
      content: '确定删除该地址？',
      success: (res) => {
        if (res.confirm) {
          // TODO: 调用删除接口
          wx.showToast({ title: '请对接删除接口', icon: 'none' });
        }
      },
    });
  },
});
