const { request } = require('../../utils/request');
const config = require('../../utils/config');

Page({
  data: {
    tab: 'code',
    showTabs: true,
    inviteCode: '',
    qrcodeUrl: '',
    qrcodeLoading: false,
    qrcodeError: '',
    recordList: [],
    texts: {
      tabCode: '\u9080\u8bf7\u7801/\u4e8c\u7ef4\u7801',
      tabRecord: '\u9080\u8bf7\u8bb0\u5f55',
      myInviteCode: '\u6211\u7684\u9080\u8bf7\u7801',
      copyInviteCode: '\u590d\u5236\u9080\u8bf7\u7801',
      inviteQrcode: '\u9080\u8bf7\u4e8c\u7ef4\u7801',
      qrcodeLoading: '\u4e8c\u7ef4\u7801\u751f\u6210\u4e2d...',
      noQrcode: '\u6682\u65e0\u4e8c\u7ef4\u7801',
      reloadQrcode: '\u91cd\u65b0\u751f\u6210',
      qrcodeTip: '\u597d\u53cb\u626b\u7801\u5373\u53ef\u6210\u4e3a\u60a8\u7684\u9080\u8bf7\u7528\u6237',
      emptyRecord: '\u6682\u65e0\u9080\u8bf7\u8bb0\u5f55',
      userPrefix: '\u7528\u6237',
      firstOrderDone: '\u5df2\u9996\u5355',
      firstOrderPending: '\u672a\u9996\u5355',
      inviteCodePending: '\u6682\u672a\u751f\u6210',
      needLoginForQrcode: '\u8bf7\u5148\u767b\u5f55\u540e\u518d\u751f\u6210\u9080\u8bf7\u4e8c\u7ef4\u7801',
      loginExpired: '\u767b\u5f55\u5df2\u8fc7\u671f\uff0c\u8bf7\u91cd\u65b0\u767b\u5f55',
      loginFirst: '\u8bf7\u5148\u767b\u5f55',
      qrcodeFailed: '\u4e8c\u7ef4\u7801\u751f\u6210\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5',
      networkError: '\u7f51\u7edc\u9519\u8bef\uff0c\u6682\u65f6\u65e0\u6cd5\u83b7\u53d6\u4e8c\u7ef4\u7801',
      noInviteCode: '\u6682\u65e0\u9080\u8bf7\u7801',
      copied: '\u5df2\u590d\u5236'
    }
  },

  onLoad(options) {
    if (options.tab === 'record') {
      this.setData({ tab: 'record' });
    }
    this.loadCode();
    this.loadRecord();
  },

  switchTab(e) {
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  loadCode() {
    const userInfo = wx.getStorageSync('userInfo');
    const inviteCode = userInfo && userInfo.inviteCode ? userInfo.inviteCode : this.data.texts.inviteCodePending;

    this.setData({ inviteCode });

    if (!userInfo || !userInfo.userId) {
      this.setData({
        qrcodeUrl: '',
        qrcodeLoading: false,
        qrcodeError: this.data.texts.needLoginForQrcode
      });
      return;
    }

    this.loadQrcode();
  },

  loadQrcode() {
    const token = wx.getStorageSync('token') || '';
    if (!token) {
      this.setData({
        qrcodeUrl: '',
        qrcodeLoading: false,
        qrcodeError: this.data.texts.loginExpired
      });
      return;
    }

    this.setData({
      qrcodeUrl: '',
      qrcodeLoading: true,
      qrcodeError: ''
    });

    wx.downloadFile({
      url: `${config.baseUrl}/api/invites/me/qrcode`,
      header: {
        Authorization: `Bearer ${token}`
      },
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300 && res.tempFilePath) {
          this.setData({
            qrcodeUrl: res.tempFilePath,
            qrcodeLoading: false,
            qrcodeError: ''
          });
          return;
        }

        if (res.statusCode === 401) {
          wx.removeStorageSync('token');
          wx.showToast({ title: this.data.texts.loginFirst, icon: 'none' });
          setTimeout(() => {
            wx.navigateTo({ url: '/pages/login/login' });
          }, 800);
        }

        this.setData({
          qrcodeUrl: '',
          qrcodeLoading: false,
          qrcodeError: this.data.texts.qrcodeFailed
        });
      },
      fail: () => {
        this.setData({
          qrcodeUrl: '',
          qrcodeLoading: false,
          qrcodeError: this.data.texts.networkError
        });
      }
    });
  },

  reloadQrcode() {
    this.loadQrcode();
  },

  loadRecord() {
    this.setData({ recordList: [] });
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo.userId) {
      return;
    }

    request({
      url: `/api/invites/${userInfo.userId}`,
      method: 'GET'
    }).then((res) => {
      const list = res.data || [];
      const mapped = list.map((item) => ({
        id: item.id,
        nickName: `${this.data.texts.userPrefix}${item.inviteeId}`,
        bindTime: item.boundAt ? item.boundAt.substring(0, 10) : '',
        hasFirstOrder: !!item.firstPaidAt
      }));
      this.setData({ recordList: mapped });
    }).catch(() => {
      this.setData({ recordList: [] });
    });
  },

  copyCode() {
    const code = this.data.inviteCode;
    if (!code || code === this.data.texts.inviteCodePending) {
      wx.showToast({ title: this.data.texts.noInviteCode, icon: 'none' });
      return;
    }

    wx.setClipboardData({
      data: code,
      success: () => wx.showToast({ title: this.data.texts.copied, icon: 'success' })
    });
  }
});
