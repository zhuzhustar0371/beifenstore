// 规则说明
Page({
  data: {},
  onLoad() {},
});
