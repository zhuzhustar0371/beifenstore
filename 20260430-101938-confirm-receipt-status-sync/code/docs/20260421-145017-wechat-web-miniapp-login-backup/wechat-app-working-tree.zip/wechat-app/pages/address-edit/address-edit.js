const { request } = require('../../utils/request.js');
const { payMiniappOrder, isWechatPaymentCancel, isWechatPaymentError } = require('../../utils/pay.js');

Page({
  data: {
    productId: null,
    quantity: 1,
    form: {
      name: '',
      phone: '',
      regionText: '',
      regionParts: [],
      detail: '',
      isDefault: false
    },
    submitting: false
  },

  onLoad(options) {
    if (options.productId && options.quantity) {
      this.setData({
        productId: options.productId,
        quantity: parseInt(options.quantity, 10)
      });
    }
  },

  onName(e) {
    this.setData({ 'form.name': e.detail.value });
  },

  onPhone(e) {
    this.setData({ 'form.phone': e.detail.value });
  },

  onRegionChange(e) {
    const regionParts = Array.isArray(e.detail.value) ? e.detail.value : [];
    this.setData({
      'form.regionParts': regionParts,
      'form.regionText': regionParts.join('')
    });
  },

  onDetail(e) {
    this.setData({ 'form.detail': e.detail.value });
  },

  onDefaultChange(e) {
    this.setData({ 'form.isDefault': !!e.detail.value });
  },

  save() {
    const { productId, quantity, form } = this.data;
    const name = (form.name || '').trim();
    const phone = (form.phone || '').trim();
    const regionText = (form.regionText || '').trim();
    const detail = (form.detail || '').trim();

    if (!name || !phone || !regionText || !detail) {
      wx.showToast({ title: '请完整填写收货信息', icon: 'none' });
      return;
    }

    if (!/^1\d{10}$/.test(phone)) {
      wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
      return;
    }

    this.setData({ submitting: true });

    let createdOrderId = null;
    request({
      url: '/api/orders',
      method: 'POST',
      data: {
        productId: parseInt(productId, 10),
        quantity,
        recipientName: name,
        recipientPhone: phone,
        address: `${regionText}${detail}`
      }
    })
      .then((res) => {
        createdOrderId = res.data.id;
        return payMiniappOrder(createdOrderId);
      })
      .then(() => {
        wx.showToast({ title: '支付成功', icon: 'success' });
        setTimeout(() => {
          wx.redirectTo({ url: `/pages/order-detail/order-detail?id=${createdOrderId}` });
        }, 1200);
      })
      .catch((error) => {
        if (!createdOrderId) {
          return;
        }

        if (isWechatPaymentCancel(error)) {
          wx.showToast({ title: '已取消支付', icon: 'none' });
        } else if (isWechatPaymentError(error)) {
          wx.showToast({ title: '支付未完成', icon: 'none' });
        }

        setTimeout(() => {
          wx.redirectTo({ url: `/pages/order-detail/order-detail?id=${createdOrderId}` });
        }, 1200);
      })
      .finally(() => {
        this.setData({ submitting: false });
      });
  }
});
