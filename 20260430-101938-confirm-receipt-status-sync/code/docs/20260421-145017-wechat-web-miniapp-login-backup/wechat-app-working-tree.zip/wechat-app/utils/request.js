const config = require('./config.js');

function extractMessage(payload, fallback) {
  if (!payload || typeof payload !== 'object') {
    return fallback;
  }

  const message = payload.message || payload.error;
  if (typeof message === 'string' && message.trim()) {
    const value = message.trim();
    if (looksTechnicalMessage(value)) {
      return fallback;
    }
    return value;
  }

  return fallback;
}

function looksTechnicalMessage(message) {
  return /###|exception|sql|select\s+.+\s+from|insert\s+into|update\s+\w+|delete\s+from/i.test(message);
}

function request(options) {
  const token = wx.getStorageSync('token') || '';
  const requestUrl =
    options.url.indexOf('http') === 0 ? options.url : `${config.baseUrl}${options.url}`;

  return new Promise((resolve, reject) => {
    wx.request({
      ...options,
      url: requestUrl,
      header: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
        ...options.header
      },
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          if (res.data && typeof res.data === 'object' && res.data.success === false) {
            wx.showToast({ title: extractMessage(res.data, '请求失败'), icon: 'none' });
            reject(res.data);
            return;
          }

          resolve(res.data);
          return;
        }

        if (res.statusCode === 401) {
          wx.removeStorageSync('token');
          wx.showToast({ title: '请先登录', icon: 'none' });
          setTimeout(() => {
            wx.navigateTo({ url: '/pages/login/login' });
          }, 1000);
          reject(res);
          return;
        }

        wx.showToast({ title: extractMessage(res.data, '请求失败'), icon: 'none' });
        reject(res);
      },
      fail: (err) => {
        wx.showToast({ title: '网络错误', icon: 'none' });
        reject(err);
      }
    });
  });
}

module.exports = { request };
