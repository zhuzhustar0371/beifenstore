<template>
  <section class="card hero">
    <h1>管理后台看板（简版）</h1>
    <p>展示平台核心运营指标，支持快速巡检。</p>
    <button class="btn-primary btn-inline" :disabled="loading" @click="load">
      {{ loading ? "刷新中..." : "刷新数据" }}
    </button>
    <FeedbackAlert v-if="hint" :type="hintType" :title="FEEDBACK_TEXT.admin.title" :message="hint" />
    <div class="grid grid-3">
      <div class="stat-card">
        <strong>总用户</strong>
        <span class="stat-value">{{ dashboard.totalUsers || 0 }}</span>
      </div>
      <div class="stat-card">
        <strong>总收入</strong>
        <span class="stat-value">¥{{ dashboard.totalIncome || 0 }}</span>
      </div>
      <div class="stat-card">
        <strong>总返现</strong>
        <span class="stat-value">¥{{ dashboard.totalCashback || 0 }}</span>
      </div>
    </div>
  </section>

  <section class="grid grid-2">
    <article class="card">
      <div class="card-title-wrap"><h2>订单列表</h2><span class="subtle">{{ orders.length }} 条</span></div>
      <div v-for="o in orders" :key="o.id" class="list-item">
        <div class="list-head">#{{ o.id }} 用户{{ o.userId }} <span class="tag-light">{{ o.status }}</span></div>
        <div class="muted">¥{{ o.totalAmount }}</div>
      </div>
      <div v-if="orders.length === 0" class="empty-state">暂无订单数据</div>
    </article>
    <article class="card">
      <div class="card-title-wrap"><h2>返现流水</h2><span class="subtle">{{ cashbacks.length }} 条</span></div>
      <div v-for="c in cashbacks" :key="c.id" class="list-item">
        <div class="list-head">{{ c.type }} / 用户{{ c.userId }}</div>
        <div class="price">¥{{ c.amount }}</div>
      </div>
      <div v-if="cashbacks.length === 0" class="empty-state">暂无返现流水</div>
    </article>
  </section>
</template>

<script setup>
import { onMounted, ref } from "vue";
import FeedbackAlert from "../components/FeedbackAlert.vue";
import { FEEDBACK_TEXT } from "../constants/feedbackMessages";
import { fetchAdminCashbacks, fetchAdminOrders, fetchDashboard, getApiErrorMessage } from "../api";

const dashboard = ref({});
const orders = ref([]);
const cashbacks = ref([]);
const loading = ref(false);
const hint = ref("");
const hintType = ref("info");

function setHint(message, type = "info") {
  hint.value = message;
  hintType.value = type;
}

async function load() {
  loading.value = true;
  try {
    const [dashboardData, orderList, cashbackList] = await Promise.all([
      fetchDashboard(),
      fetchAdminOrders(),
      fetchAdminCashbacks()
    ]);
    dashboard.value = dashboardData;
    orders.value = orderList;
    cashbacks.value = cashbackList;
    setHint(FEEDBACK_TEXT.admin.refreshSuccess, "success");
  } catch (error) {
    setHint(getApiErrorMessage(error, FEEDBACK_TEXT.admin.refreshFail), "error");
  } finally {
    loading.value = false;
  }
}

onMounted(load);
</script>
