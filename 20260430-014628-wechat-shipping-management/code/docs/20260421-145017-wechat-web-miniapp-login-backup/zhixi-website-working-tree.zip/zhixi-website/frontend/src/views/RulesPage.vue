<template>
  <div class="container page-shell">
    <div class="page-header">
      <div class="page-header-copy">
        <span class="section-eyebrow">规则说明</span>
        <h1>返现规则说明</h1>
        <p>
          系统基于订单支付记录自动结算返现，规则公开透明、可查询、可追踪。你可以先看懂再下单，不需要来回切换页面。
        </p>
      </div>
    </div>

    <div class="rule-summary-grid">
      <div class="rule-summary-card">
        <span class="summary-label">复购最高返现</span>
        <strong class="summary-value">¥69.3</strong>
        <p class="summary-note">第 4 单可获得 70% 的返现金额。</p>
      </div>
      <div class="rule-summary-card">
        <span class="summary-label">邀请结算门槛</span>
        <strong class="summary-value">3 人 / 批</strong>
        <p class="summary-note">每满 3 位首单支付用户结算一批邀请返现。</p>
      </div>
      <div class="rule-summary-card">
        <span class="summary-label">结算触发点</span>
        <strong class="summary-value">支付成功后</strong>
        <p class="summary-note">订单支付完成后自动执行返现写入，无需手动申请。</p>
      </div>
      <div class="rule-summary-card">
        <span class="summary-label">数据一致性</span>
        <strong class="summary-value">官网 / 小程序统一</strong>
        <p class="summary-note">官网与小程序共用后端规则，记录口径保持一致。</p>
      </div>
    </div>

    <div class="rules-grid">
      <div class="rule-card">
        <div class="rule-card-title">
          <div class="rule-card-copy">
            <h2>个人下单返现</h2>
            <p>按同一用户历史支付顺序统计，顺序越靠后返现越高。</p>
          </div>
          <span class="tag tag-green">按订单顺序</span>
        </div>

        <table class="rule-table">
          <thead>
            <tr>
              <th>订单次序</th>
              <th>返现金额</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>第 1 单</td>
              <td>不返现</td>
            </tr>
            <tr>
              <td>第 2 单</td>
              <td><strong>返现 9.9 元（10%）</strong></td>
            </tr>
            <tr>
              <td>第 3 单</td>
              <td><strong>返现 19.8 元（20%）</strong></td>
            </tr>
            <tr>
              <td>第 4 单</td>
              <td><strong>返现 69.3 元（70%）</strong></td>
            </tr>
            <tr>
              <td>第 5 单及以后</td>
              <td>不返现</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="rule-card">
        <div class="rule-card-title">
          <div class="rule-card-copy">
            <h2>邀请返现</h2>
            <p>按被邀请用户首单支付时间划分批次，每满 3 人结算一批。</p>
          </div>
          <span class="tag tag-amber">每满 3 人</span>
        </div>

        <table class="rule-table">
          <thead>
            <tr>
              <th>被邀请人批次</th>
              <th>邀请人获得</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>第 1 批（满 3 人）</td>
              <td><strong>返现 99 元</strong></td>
            </tr>
            <tr>
              <td>第 2 批（再满 3 人）</td>
              <td><strong>返现 20 元</strong></td>
            </tr>
            <tr>
              <td>第 3 批及以后</td>
              <td><strong>每批 20 元</strong></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="rule-card rule-card-spaced">
      <div class="rule-card-title">
        <div class="rule-card-copy">
          <h2>结算说明</h2>
          <p>把最关心的触发条件、记录位置和数据口径直接放在同一个区块里。</p>
        </div>
        <span class="tag tag-gray">以支付时间为准</span>
      </div>

      <table class="rule-table">
        <thead>
          <tr>
            <th>说明项</th>
            <th>内容</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>结算触发</td>
            <td><strong>订单支付成功后自动执行</strong></td>
          </tr>
          <tr>
            <td>返现记录</td>
            <td><strong>用户中心可查看明细与金额</strong></td>
          </tr>
          <tr>
            <td>邀请统计</td>
            <td><strong>仅统计被邀请用户首单支付</strong></td>
          </tr>
          <tr>
            <td>数据一致性</td>
            <td><strong>官网与小程序同一后端规则</strong></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="rule-note">
      <strong>温馨提示</strong>
      <ul class="list-checks">
        <li>返现按用户历史订单顺序计算，与是否被邀请无关。</li>
        <li>邀请返现按被邀请用户首次付款时间分批，每满 3 人结算一批。</li>
        <li>同一用户只计入首单，不重复计入多批。</li>
      </ul>
    </div>
  </div>
</template>
