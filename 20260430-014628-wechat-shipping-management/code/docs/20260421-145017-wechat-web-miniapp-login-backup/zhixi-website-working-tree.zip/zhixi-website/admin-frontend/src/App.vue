<template>
  <div v-if="!loggedIn" class="login-page">
    <div class="login-card">
      <h1>知禧管理后台</h1>
      <p>请输入管理员账号和密码登录</p>
      <div class="form">
        <input v-model="loginForm.username" placeholder="管理员账号" />
        <input
          v-model="loginForm.password"
          type="password"
          placeholder="管理员密码"
          @keyup.enter="onLogin"
        />
        <button class="btn-primary" @click="onLogin">登录后台</button>
      </div>
    </div>
  </div>

  <div v-else class="layout">
    <header class="header shell">
      <div>
        <h1>知禧管理后台</h1>
        <p>{{ adminInfo.displayName || adminInfo.username }}，欢迎回来</p>
      </div>
      <div class="header-actions">
        <button class="btn-ghost" @click="loadAll">刷新数据</button>
        <button class="btn-primary" @click="onLogout">退出登录</button>
      </div>
    </header>

    <main class="shell admin-body">
      <aside class="sidebar">
        <a href="#overview">看板概览</a>
        <a href="#users">用户管理</a>
        <a href="#products">商品管理</a>
        <a href="#orders">订单管理</a>
        <a href="#invites">邀请管理</a>
        <a href="#cashbacks">返现管理</a>
      </aside>

      <div class="content">
        <section id="overview" class="stats">
          <article class="stat">
            <span>总用户</span>
            <strong>{{ dashboard.totalUsers || 0 }}</strong>
          </article>
          <article class="stat">
            <span>总收入</span>
            <strong>¥{{ dashboard.totalIncome || 0 }}</strong>
          </article>
          <article class="stat">
            <span>总返现</span>
            <strong>¥{{ dashboard.totalCashback || 0 }}</strong>
          </article>
        </section>

        <section class="dashboard-grid">
          <article id="users" class="card compact-card">
            <div class="card-head">
              <h2>用户管理</h2>
              <span>{{ users.length }} 人</span>
            </div>
            <div v-for="u in users" :key="u.id" class="item">
              <div>#{{ u.id }} {{ u.nickname || "未命名用户" }}</div>
              <div>{{ u.phone || u.mobile || "-" }}</div>
            </div>
            <div v-if="users.length === 0" class="empty">暂无用户数据</div>
          </article>

          <article id="products" class="card compact-card">
            <div class="card-head">
              <h2>商品管理</h2>
              <span>{{ products.length }} 件</span>
            </div>
            <div v-for="p in products" :key="p.id" class="item">
              <div>{{ p.name }} / ¥{{ p.price }}</div>
              <div class="item-actions">
                <b>{{ p.active ? "上架中" : "已下架" }}</b>
                <button class="btn-inline" @click="toggleProduct(p)">
                  {{ p.active ? "下架" : "上架" }}
                </button>
              </div>
            </div>
            <div v-if="products.length === 0" class="empty">暂无商品数据</div>
          </article>

          <article id="invites" class="card compact-card">
            <div class="card-head">
              <h2>邀请管理</h2>
              <span>{{ invites.length }} 条</span>
            </div>
            <div v-for="item in invites" :key="item.id" class="item">
              <div>邀请人 {{ item.inviterId }} -> 被邀请人 {{ item.inviteeId }}</div>
              <div>{{ item.firstPaidAt || "未首单" }}</div>
            </div>
            <div v-if="invites.length === 0" class="empty">暂无邀请数据</div>
          </article>

          <article id="orders" class="card wide-card">
            <div class="card-head">
              <h2>订单管理</h2>
              <span>{{ orders.length }} 单</span>
            </div>
            <div v-if="orders.length > 0" class="table-wrap">
              <table class="data-table order-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>用户ID</th>
                    <th>金额</th>
                    <th>状态</th>
                    <th>物流单号</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="order in orders" :key="order.id">
                    <td>#{{ order.id }}</td>
                    <td>{{ order.userId }}</td>
                    <td>¥{{ order.totalAmount }}</td>
                    <td>
                      <span :class="['status-badge', orderStatusClass(order.status)]">
                        {{ orderStatusText(order.status) }}
                      </span>
                    </td>
                    <td>
                      <input
                        v-model="trackingMap[order.id]"
                        class="table-input"
                        placeholder="物流单号"
                      />
                    </td>
                    <td>
                      <button class="btn-inline" @click="onShip(order.id)">发货</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div v-else class="empty">暂无订单数据</div>
          </article>

          <article id="cashbacks" class="card wide-card">
            <div class="card-head cashback-head">
              <div>
                <h2>返现管理</h2>
                <div class="cashback-subtitle">批准后立即发起微信商家转账</div>
              </div>
              <span>{{ cashbacks.length }} 条</span>
            </div>

            <div class="cashback-filters">
              <input
                v-model.trim="cashbackFilters.userId"
                class="filter-input"
                placeholder="用户ID"
              />
              <select v-model="cashbackFilters.type" class="filter-input">
                <option value="">全部类型</option>
                <option value="PERSONAL_ORDER">自购返现</option>
                <option value="INVITE_BATCH">邀请返现</option>
              </select>
              <select v-model="cashbackFilters.status" class="filter-input">
                <option value="">全部状态</option>
                <option value="PENDING">待结算</option>
                <option value="PROCESSING">打款中</option>
                <option value="TRANSFERRED">已到账</option>
                <option value="FAILED">打款失败</option>
                <option value="CANCELLED">已取消</option>
              </select>
              <button class="btn-primary btn-search" @click="loadCashbacks">查询</button>
            </div>

            <div v-if="transferMessage" :class="['transfer-banner', transferBannerClass]">
              {{ transferMessage }}
            </div>

            <div v-if="cashbacks.length > 0" class="table-wrap">
              <table class="data-table cashback-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>用户ID</th>
                    <th>订单ID</th>
                    <th>类型</th>
                    <th>金额</th>
                    <th>状态</th>
                    <th>备注</th>
                    <th>创建时间</th>
                    <th>打款批次</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="cashback in cashbacks" :key="cashback.id">
                    <td>{{ cashback.id }}</td>
                    <td>{{ cashback.userId }}</td>
                    <td>{{ cashback.orderId || "-" }}</td>
                    <td>
                      <span class="status-badge info">{{ cashbackTypeText(cashback.type) }}</span>
                    </td>
                    <td>¥{{ cashback.amount }}</td>
                    <td>
                      <span :class="['status-badge', statusClass(cashback.status)]">
                        {{ cashbackStatusText(cashback.status) }}
                      </span>
                    </td>
                    <td>{{ cashback.remark || "-" }}</td>
                    <td>{{ cashback.createdAt || "-" }}</td>
                    <td>{{ cashback.outBatchNo || cashback.transferId || "-" }}</td>
                    <td>
                      <button
                        class="btn-inline btn-transfer"
                        :disabled="transferringId === cashback.id || cashback.status !== 'PENDING'"
                        @click="onTransferCashback(cashback)"
                      >
                        {{
                          transferringId === cashback.id
                            ? "处理中"
                            : cashback.status === "PENDING"
                              ? "批准打款"
                              : "不可操作"
                        }}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div v-else class="empty">暂无返现数据</div>
          </article>
        </section>
      </div>
    </main>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from "vue";
import {
  adminLogin,
  adminLogout,
  clearAdminToken,
  fetchAdminCashbacks,
  fetchAdminInvites,
  fetchAdminMe,
  fetchAdminOrders,
  fetchAdminProducts,
  fetchAdminUsers,
  fetchDashboard,
  getAdminToken,
  setAdminToken,
  shipOrder,
  transferCashback,
  updateProductStatus
} from "./api";

const loggedIn = ref(false);
const adminInfo = ref({});
const dashboard = ref({});
const orders = ref([]);
const cashbacks = ref([]);
const users = ref([]);
const products = ref([]);
const invites = ref([]);
const transferringId = ref(null);
const transferMessage = ref("");
const transferBannerClass = ref("info");
const trackingMap = reactive({});

const loginForm = reactive({
  username: "zhixi_admin",
  password: ""
});

const cashbackFilters = reactive({
  userId: "",
  type: "",
  status: ""
});

async function onLogin() {
  const res = await adminLogin(loginForm);
  setAdminToken(res.token);
  adminInfo.value = { username: res.username, displayName: res.displayName };
  loggedIn.value = true;
  await loadAll();
}

async function onLogout() {
  try {
    await adminLogout();
  } finally {
    clearAdminToken();
    loggedIn.value = false;
    adminInfo.value = {};
  }
}

async function loadCashbacks() {
  const userId = cashbackFilters.userId ? Number(cashbackFilters.userId) : undefined;
  cashbacks.value = await fetchAdminCashbacks({
    userId: Number.isFinite(userId) ? userId : undefined,
    type: cashbackFilters.type || undefined,
    status: cashbackFilters.status || undefined
  });
}

async function loadAll() {
  dashboard.value = await fetchDashboard();
  orders.value = await fetchAdminOrders();
  await loadCashbacks();
  users.value = await fetchAdminUsers();
  products.value = await fetchAdminProducts();
  invites.value = await fetchAdminInvites();
}

async function toggleProduct(product) {
  await updateProductStatus(product.id, !product.active);
  await loadAll();
}

async function onShip(orderId) {
  const trackingNo = trackingMap[orderId];
  if (!trackingNo) return;
  await shipOrder(orderId, trackingNo);
  trackingMap[orderId] = "";
  await loadAll();
}

function showTransferMessage(message, type = "info") {
  transferMessage.value = message;
  transferBannerClass.value = type;
}

function statusClass(status) {
  if (status === "PENDING") return "warning";
  if (status === "PROCESSING") return "info";
  if (status === "TRANSFERRED") return "success";
  if (status === "FAILED") return "danger";
  return "muted";
}

function orderStatusClass(status) {
  if (status === "PAID") return "success";
  if (status === "PENDING") return "warning";
  if (status === "SHIPPED" || status === "COMPLETED") return "info";
  return "muted";
}

function orderStatusText(status) {
  const map = {
    PENDING: "待支付",
    PAID: "已支付",
    SHIPPED: "已发货",
    COMPLETED: "已完成",
    CANCELLED: "已取消",
    REFUNDED: "已退款"
  };
  return map[status] || status || "-";
}

function cashbackTypeText(type) {
  const map = {
    PERSONAL_ORDER: "自购返现",
    INVITE_BATCH: "邀请返现",
    DOWNLINE_FIRST_ORDER: "邀请首单奖励",
    DOWNLINE_REPEAT_ORDER: "邀请复购奖励"
  };
  return map[type] || type || "-";
}

function cashbackStatusText(status) {
  const map = {
    PENDING: "待结算",
    PROCESSING: "打款中",
    TRANSFERRED: "已到账",
    CANCELLED: "已取消",
    FAILED: "打款失败"
  };
  return map[status] || status || "-";
}

async function onTransferCashback(cashback) {
  const ok = window.confirm(
    `确认批准并发起打款？\n返现ID：${cashback.id}\n用户ID：${cashback.userId}\n金额：¥${cashback.amount}`
  );
  if (!ok) return;

  transferringId.value = cashback.id;
  showTransferMessage(`正在提交返现 #${cashback.id} 的打款请求...`);
  try {
    await transferCashback(cashback.id);
    await loadCashbacks();
    showTransferMessage(
      `返现 #${cashback.id} 已发起打款，状态已更新为“打款中”。`,
      "success"
    );
  } catch (error) {
    const message = error?.response?.data?.message || error?.message || "批准打款失败";
    showTransferMessage(message, "danger");
    window.alert(message);
  } finally {
    transferringId.value = null;
  }
}

onMounted(async () => {
  const token = getAdminToken();
  if (!token) {
    loggedIn.value = false;
    return;
  }
  try {
    adminInfo.value = await fetchAdminMe();
    loggedIn.value = true;
    await loadAll();
  } catch (_e) {
    clearAdminToken();
    loggedIn.value = false;
  }
});
</script>
