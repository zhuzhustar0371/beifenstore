package com.zhixi.backend.controller;

import com.zhixi.backend.common.ApiResponse;
import com.zhixi.backend.model.CashbackRecord;
import com.zhixi.backend.service.CashbackService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/cashbacks")
public class CashbackController {
  private final CashbackService cashbackService;

  public CashbackController(CashbackService cashbackService) {
    this.cashbackService = cashbackService;
  }

  @GetMapping("/{userId}")
  public ApiResponse<List<CashbackRecord>> listByUser(@PathVariable Long userId) {
    return ApiResponse.ok(cashbackService.listByUser(userId));
  }
}
