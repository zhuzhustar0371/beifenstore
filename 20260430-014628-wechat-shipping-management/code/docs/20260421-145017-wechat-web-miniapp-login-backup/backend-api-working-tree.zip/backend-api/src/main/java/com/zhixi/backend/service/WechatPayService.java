package com.zhixi.backend.service;

import com.wechat.pay.java.core.Config;
import com.wechat.pay.java.core.RSAAutoCertificateConfig;
import com.wechat.pay.java.core.RSAPublicKeyConfig;
import com.wechat.pay.java.core.exception.HttpException;
import com.wechat.pay.java.core.exception.ServiceException;
import com.wechat.pay.java.service.payments.jsapi.JsapiServiceExtension;
import com.wechat.pay.java.service.payments.jsapi.model.Amount;
import com.wechat.pay.java.service.payments.jsapi.model.Payer;
import com.wechat.pay.java.service.payments.jsapi.model.PrepayRequest;
import com.wechat.pay.java.service.payments.jsapi.model.PrepayWithRequestPaymentResponse;
import com.wechat.pay.java.service.payments.nativepay.NativePayService;
import com.wechat.pay.java.service.payments.nativepay.model.PrepayResponse;
import com.wechat.pay.java.service.refund.RefundService;
import com.wechat.pay.java.service.refund.model.AmountReq;
import com.wechat.pay.java.service.refund.model.CreateRequest;
import com.wechat.pay.java.service.refund.model.Refund;
import com.wechat.pay.java.service.transferbatch.TransferBatchService;
import com.wechat.pay.java.service.transferbatch.model.InitiateBatchTransferRequest;
import com.wechat.pay.java.service.transferbatch.model.InitiateBatchTransferResponse;
import com.wechat.pay.java.service.transferbatch.model.TransferDetailInput;
import com.zhixi.backend.common.BusinessException;
import com.zhixi.backend.model.CashbackRecord;
import com.zhixi.backend.model.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;

@Service
public class WechatPayService {
  private static final Logger log = LoggerFactory.getLogger(WechatPayService.class);

  @Value("${app.wechat.pay.mchid}")
  private String mchId;

  @Value("${app.wechat.pay.appid}")
  private String appId;

  @Value("${app.wechat.pay.api-v3-key}")
  private String apiV3Key;

  @Value("${app.wechat.pay.merchant-serial-number}")
  private String merchantSerialNumber;

  @Value("${app.wechat.pay.private-key-path}")
  private String privateKeyPath;

  @Value("${app.wechat.pay.notify-url}")
  private String notifyUrl;

  @Value("${app.wechat.pay.public-key-id:}")
  private String publicKeyId;

  @Value("${app.wechat.pay.public-key-path:}")
  private String publicKeyPath;

  @Value("${app.wechat.pay.public-key-pem:}")
  private String publicKeyPem;

  private Config wechatPayConfig;
  private JsapiServiceExtension jsapiService;
  private NativePayService nativePayService;
  private RefundService refundService;
  private TransferBatchService transferBatchService;
  private String resolvedPublicKeyPath;

  private synchronized void init() {
    if (wechatPayConfig != null) {
      return;
    }

    requireConfigured("WECHAT_PAY_MCHID", mchId);
    requireConfigured("WECHAT_PAY_APPID", appId);
    requireConfigured("WECHAT_PAY_API_V3_KEY", apiV3Key);
    requireConfigured("WECHAT_PAY_SERIAL_NUMBER", merchantSerialNumber);
    requireConfigured("WECHAT_PAY_PRIVATE_KEY_PATH", privateKeyPath);
    requireConfigured("WECHAT_PAY_NOTIFY_URL", notifyUrl);

    try {
      if (isConfigured(publicKeyId) || isConfigured(publicKeyPath) || isConfigured(publicKeyPem)) {
        requireConfigured("WECHAT_PAY_PUBLIC_KEY_ID", publicKeyId);
        String publicKeyFilePath = resolvePublicKeyPath();
        wechatPayConfig = new RSAPublicKeyConfig.Builder()
            .merchantId(mchId)
            .privateKeyFromPath(privateKeyPath)
            .merchantSerialNumber(merchantSerialNumber)
            .apiV3Key(apiV3Key)
            .publicKeyId(publicKeyId)
            .publicKeyFromPath(publicKeyFilePath)
            .build();
      } else {
        wechatPayConfig = new RSAAutoCertificateConfig.Builder()
            .merchantId(mchId)
            .privateKeyFromPath(privateKeyPath)
            .merchantSerialNumber(merchantSerialNumber)
            .apiV3Key(apiV3Key)
            .build();
      }
      jsapiService = new JsapiServiceExtension.Builder().config(wechatPayConfig).build();
      nativePayService = new NativePayService.Builder().config(wechatPayConfig).build();
      refundService = new RefundService.Builder().config(wechatPayConfig).build();
      transferBatchService = new TransferBatchService.Builder().config(wechatPayConfig).build();
    } catch (Exception e) {
      log.error("Failed to initialize WeChat Pay SDK", e);
      throw new BusinessException("WeChat Pay environment initialization failed");
    }
  }

  public PrepayWithRequestPaymentResponse createJsapiOrder(Order order, String openid, String description) {
    init();
    if (order.getOrderNo() == null || order.getOrderNo().isBlank()) {
      throw new BusinessException("Order number is missing");
    }
    if (openid == null || openid.isBlank()) {
      throw new BusinessException("Miniapp openid is missing");
    }

    PrepayRequest request = new PrepayRequest();
    request.setAppid(appId);
    request.setMchid(mchId);
    request.setDescription(description);
    request.setOutTradeNo(order.getOrderNo());
    request.setNotifyUrl(notifyUrl);

    Amount amount = new Amount();
    try {
      amount.setTotal(order.getTotalAmount().movePointRight(2).intValueExact());
    } catch (ArithmeticException ex) {
      throw new BusinessException("Order amount is invalid");
    }
    if (amount.getTotal() == null || amount.getTotal() <= 0) {
      throw new BusinessException("Order amount must be greater than zero");
    }
    amount.setCurrency("CNY");
    request.setAmount(amount);

    Payer payer = new Payer();
    payer.setOpenid(openid);
    request.setPayer(payer);

    try {
      return jsapiService.prepayWithRequestPayment(request);
    } catch (ServiceException e) {
      log.error("WeChat Pay unified order failed: {}", e.getErrorMessage());
      throw new BusinessException("WeChat Pay unified order failed: " + e.getErrorMessage());
    } catch (HttpException e) {
      log.error("WeChat Pay network error: {}", e.getMessage());
      throw new BusinessException("WeChat Pay network error");
    }
  }

  public PrepayResponse createNativeOrder(Order order, String description) {
    init();
    if (order.getOrderNo() == null || order.getOrderNo().isBlank()) {
      throw new BusinessException("Order number is missing");
    }

    com.wechat.pay.java.service.payments.nativepay.model.PrepayRequest request =
        new com.wechat.pay.java.service.payments.nativepay.model.PrepayRequest();
    request.setAppid(appId);
    request.setMchid(mchId);
    request.setDescription(description);
    request.setOutTradeNo(order.getOrderNo());
    request.setNotifyUrl(notifyUrl);

    com.wechat.pay.java.service.payments.nativepay.model.Amount amount =
        new com.wechat.pay.java.service.payments.nativepay.model.Amount();
    try {
      amount.setTotal(order.getTotalAmount().movePointRight(2).intValueExact());
    } catch (ArithmeticException ex) {
      throw new BusinessException("Order amount is invalid");
    }
    if (amount.getTotal() == null || amount.getTotal() <= 0) {
      throw new BusinessException("Order amount must be greater than zero");
    }
    amount.setCurrency("CNY");
    request.setAmount(amount);

    try {
      return nativePayService.prepay(request);
    } catch (ServiceException e) {
      log.error("WeChat Native Pay unified order failed: {}", e.getErrorMessage());
      throw new BusinessException("WeChat Native Pay unified order failed: " + e.getErrorMessage());
    } catch (HttpException e) {
      log.error("WeChat Native Pay network error: {}", e.getMessage());
      throw new BusinessException("WeChat Native Pay network error");
    }
  }

  public Refund refundOrder(Order order, String reason) {
    init();
    if (order.getTransactionId() == null || order.getTransactionId().isBlank()) {
      throw new BusinessException("Current order has no WeChat transaction id");
    }

    CreateRequest request = new CreateRequest();
    request.setTransactionId(order.getTransactionId());
    request.setOutRefundNo("RF" + order.getId() + "T" + System.currentTimeMillis());
    request.setReason(reason);

    AmountReq amount = new AmountReq();
    amount.setRefund(order.getTotalAmount().multiply(new BigDecimal("100")).longValue());
    amount.setTotal(order.getTotalAmount().multiply(new BigDecimal("100")).longValue());
    amount.setCurrency("CNY");
    request.setAmount(amount);

    try {
      return refundService.create(request);
    } catch (Exception e) {
      log.error("WeChat refund failed", e);
      throw new BusinessException("WeChat refund request failed");
    }
  }

  public InitiateBatchTransferResponse transferToWallet(CashbackRecord cb, String openid) {
    init();

    InitiateBatchTransferRequest request = new InitiateBatchTransferRequest();
    request.setAppid(appId);

    String outBatchNo = "BATCH" + cb.getId() + "T" + System.currentTimeMillis();
    cb.setOutBatchNo(outBatchNo);
    request.setOutBatchNo(outBatchNo);
    request.setBatchName("Zhixi cashback settlement " + cb.getId());
    request.setBatchRemark("Cashback settlement");
    request.setTotalAmount(cb.getAmount().multiply(new BigDecimal("100")).longValue());
    request.setTotalNum(1);

    TransferDetailInput detail = new TransferDetailInput();
    String outDetailNo = "DETAIL" + cb.getId();
    cb.setOutDetailNo(outDetailNo);
    detail.setOutDetailNo(outDetailNo);
    detail.setTransferAmount(cb.getAmount().multiply(new BigDecimal("100")).longValue());
    detail.setTransferRemark("Cashback settlement");
    detail.setOpenid(openid);

    request.setTransferDetailList(Collections.singletonList(detail));

    try {
      return transferBatchService.initiateBatchTransfer(request);
    } catch (Exception e) {
      log.error("WeChat transfer failed", e);
      throw new BusinessException("Merchant transfer failed");
    }
  }

  public Config getConfig() {
    init();
    return wechatPayConfig;
  }

  private void requireConfigured(String name, String value) {
    if (value == null || value.isBlank()) {
      throw new BusinessException(name + " is not configured");
    }
  }

  private boolean isConfigured(String value) {
    return value != null && !value.isBlank();
  }

  private String resolvePublicKeyPath() throws Exception {
    if (isConfigured(resolvedPublicKeyPath)) {
      return resolvedPublicKeyPath;
    }
    if (isConfigured(publicKeyPath)) {
      resolvedPublicKeyPath = publicKeyPath;
      return resolvedPublicKeyPath;
    }
    requireConfigured("WECHAT_PAY_PUBLIC_KEY_PEM", publicKeyPem);

    String normalizedPem = publicKeyPem.trim().replace("\r\n", "\n");
    Path tempFile = Files.createTempFile("wechatpay-public-key-", ".pem");
    Files.writeString(tempFile, normalizedPem + "\n", StandardCharsets.UTF_8);
    tempFile.toFile().deleteOnExit();
    resolvedPublicKeyPath = tempFile.toAbsolutePath().toString();
    return resolvedPublicKeyPath;
  }
}
