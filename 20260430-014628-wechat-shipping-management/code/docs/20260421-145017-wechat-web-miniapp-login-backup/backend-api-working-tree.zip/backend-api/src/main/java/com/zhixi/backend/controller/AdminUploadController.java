package com.zhixi.backend.controller;

import com.zhixi.backend.common.ApiResponse;
import com.zhixi.backend.common.BusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin/uploads")
public class AdminUploadController {
  @Value("${app.upload.dir:uploads}")
  private String uploadDir;

  @PostMapping("/image")
  public ApiResponse<Map<String, String>> uploadImage(
      @RequestParam("file") MultipartFile file,
      HttpServletRequest request
  ) {
    if (file == null || file.isEmpty()) {
      throw new BusinessException("请选择要上传的图片");
    }
    String contentType = file.getContentType();
    if (contentType == null || !contentType.startsWith("image/")) {
      throw new BusinessException("仅支持图片文件");
    }
    if (file.getSize() > 2 * 1024 * 1024) {
      throw new BusinessException("图片大小不能超过2MB");
    }
    String ext = StringUtils.getFilenameExtension(file.getOriginalFilename());
    if (ext == null || ext.isBlank()) {
      ext = "png";
    }
    String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext.toLowerCase();
    Path dir = Paths.get(uploadDir).toAbsolutePath();
    Path target = dir.resolve(filename);
    try {
      Files.createDirectories(dir);
      file.transferTo(target);
    } catch (IOException e) {
      throw new BusinessException("图片上传失败");
    }
    String scheme = request.getHeader("X-Forwarded-Proto");
    if (scheme == null || scheme.isBlank()) {
      scheme = request.getScheme();
    }
    String host = request.getHeader("Host");
    if (host == null || host.isBlank()) {
      host = request.getServerName();
    }
    String url = scheme + "://" + host + "/api/uploads/" + filename;
    Map<String, String> data = new HashMap<>();
    data.put("url", url);
    data.put("filename", filename);
    return ApiResponse.ok(data);
  }
}
