package com.zhixi.backend.mapper;

import com.zhixi.backend.model.CashbackRecord;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface CashbackRecordMapper {
  @Insert("INSERT INTO cashback_records(user_id,related_order_id,cashback_type,amount,related_invite_batch_id,status,remark,out_batch_no,out_detail_no,created_at) " +
      "VALUES(#{userId},#{orderId},#{type},#{amount},#{batchNo},#{status},#{remark},#{outBatchNo},#{outDetailNo},NOW())")
  @Options(useGeneratedKeys = true, keyProperty = "id")
  int insert(CashbackRecord record);

  @Select("SELECT id,user_id AS userId,related_order_id AS orderId,cashback_type AS type,amount,related_invite_batch_id AS batchNo,status,remark,out_batch_no AS outBatchNo,out_detail_no AS outDetailNo,transfer_id AS transferId,transfer_time AS transferTime,created_at AS createdAt " +
      "FROM cashback_records WHERE id = #{id}")
  CashbackRecord findById(Long id);

  @Select("SELECT id,user_id AS userId,related_order_id AS orderId,cashback_type AS type,amount,related_invite_batch_id AS batchNo,status,remark,out_batch_no AS outBatchNo,out_detail_no AS outDetailNo,transfer_id AS transferId,transfer_time AS transferTime,created_at AS createdAt " +
      "FROM cashback_records WHERE user_id = #{userId} ORDER BY id DESC")
  List<CashbackRecord> findByUserId(Long userId);

  @Select("SELECT id,user_id AS userId,related_order_id AS orderId,cashback_type AS type,amount,related_invite_batch_id AS batchNo,status,remark,out_batch_no AS outBatchNo,out_detail_no AS outDetailNo,transfer_id AS transferId,transfer_time AS transferTime,created_at AS createdAt " +
      "FROM cashback_records ORDER BY id DESC")
  List<CashbackRecord> findAll();

  @Select({
      "<script>",
      "SELECT COUNT(1) FROM cashback_records",
      "WHERE 1=1",
      "<if test='userId != null'>",
      "  AND user_id = #{userId}",
      "</if>",
      "<if test='type != null and type != \"\"'>",
      "  AND cashback_type = #{type}",
      "</if>",
      "<if test='status != null and status != \"\"'>",
      "  AND status = #{status}",
      "</if>",
      "</script>"
  })
  long countByAdminQuery(
      @Param("userId") Long userId,
      @Param("type") String type,
      @Param("status") String status
  );

  @Select({
      "<script>",
      "SELECT id,user_id AS userId,related_order_id AS orderId,cashback_type AS type,amount,related_invite_batch_id AS batchNo,status,remark,out_batch_no AS outBatchNo,out_detail_no AS outDetailNo,transfer_id AS transferId,transfer_time AS transferTime,created_at AS createdAt FROM cashback_records",
      "WHERE 1=1",
      "<if test='userId != null'>",
      "  AND user_id = #{userId}",
      "</if>",
      "<if test='type != null and type != \"\"'>",
      "  AND cashback_type = #{type}",
      "</if>",
      "<if test='status != null and status != \"\"'>",
      "  AND status = #{status}",
      "</if>",
      "ORDER BY id DESC",
      "LIMIT #{limit} OFFSET #{offset}",
      "</script>"
  })
  List<CashbackRecord> findByAdminQuery(
      @Param("userId") Long userId,
      @Param("type") String type,
      @Param("status") String status,
      @Param("offset") int offset,
      @Param("limit") int limit
  );

  @Select("SELECT COUNT(1) FROM cashback_records WHERE user_id = #{userId} AND cashback_type = 'INVITE_BATCH' AND related_invite_batch_id = #{batchNo}")
  int existsInviteBatch(@Param("userId") Long userId, @Param("batchNo") Integer batchNo);

  @Update("UPDATE cashback_records SET status = #{status}, out_batch_no = #{outBatchNo}, out_detail_no = #{outDetailNo}, transfer_id = #{transferId}, transfer_time = #{transferTime} WHERE id = #{id}")
  int updateTransferInfo(
      @Param("id") Long id,
      @Param("status") String status,
      @Param("outBatchNo") String outBatchNo,
      @Param("outDetailNo") String outDetailNo,
      @Param("transferId") String transferId,
      @Param("transferTime") java.time.LocalDateTime transferTime
  );

  @Select("SELECT COALESCE(SUM(amount),0) FROM cashback_records")
  Double totalAmount();

  @Select("SELECT COALESCE(SUM(amount),0) FROM cashback_records WHERE DATE(created_at) = CURRENT_DATE")
  Double todayAmount();
}
