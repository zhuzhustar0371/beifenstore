package com.zhixi.backend.service;

import com.zhixi.backend.mapper.CashbackRecordMapper;
import com.zhixi.backend.model.CashbackRecord;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class CashbackService {
  private static final BigDecimal INVITE_REPEAT_RATIO =
      BigDecimal.valueOf(20).divide(BigDecimal.valueOf(99), 8, RoundingMode.HALF_UP);

  private final CashbackRecordMapper cashbackRecordMapper;

  public CashbackService(CashbackRecordMapper cashbackRecordMapper) {
    this.cashbackRecordMapper = cashbackRecordMapper;
  }

  public void grantPersonalCashback(Long userId, Long orderId, int paidOrderSeq, BigDecimal orderAmount) {
    BigDecimal amount = switch (paidOrderSeq) {
      case 2 -> ratio(orderAmount, BigDecimal.valueOf(0.10));
      case 3 -> ratio(orderAmount, BigDecimal.valueOf(0.20));
      case 4 -> ratio(orderAmount, BigDecimal.valueOf(0.70));
      default -> BigDecimal.ZERO;
    };
    if (amount.compareTo(BigDecimal.ZERO) <= 0) {
      return;
    }

    CashbackRecord record = new CashbackRecord();
    record.setUserId(userId);
    record.setOrderId(orderId);
    record.setType("PERSONAL_ORDER");
    record.setAmount(amount);
    record.setStatus("PENDING");
    record.setRemark("个人第" + paidOrderSeq + "单返现");
    cashbackRecordMapper.insert(record);
  }

  public void grantInviteBatchCashback(Long inviterId, int firstPaidCount, BigDecimal firstOrderAmount) {
    if (firstPaidCount % 3 != 0) {
      return;
    }

    int batchNo = firstPaidCount / 3;
    if (cashbackRecordMapper.existsInviteBatch(inviterId, batchNo) > 0) {
      return;
    }

    BigDecimal amount = batchNo == 1
        ? money(firstOrderAmount)
        : ratio(firstOrderAmount, INVITE_REPEAT_RATIO);
    CashbackRecord record = new CashbackRecord();
    record.setUserId(inviterId);
    record.setType("INVITE_BATCH");
    record.setAmount(amount);
    record.setBatchNo(batchNo);
    record.setStatus("PENDING");
    record.setRemark("邀请返现第" + batchNo + "批");
    cashbackRecordMapper.insert(record);
  }

  public List<CashbackRecord> listByUser(Long userId) {
    return cashbackRecordMapper.findByUserId(userId);
  }

  public List<CashbackRecord> listAll() {
    return cashbackRecordMapper.findAll();
  }

  public double totalCashbackAmount() {
    Double value = cashbackRecordMapper.totalAmount();
    return value == null ? 0D : value;
  }

  private BigDecimal ratio(BigDecimal baseAmount, BigDecimal ratio) {
    if (baseAmount == null) {
      return BigDecimal.ZERO;
    }
    return baseAmount.multiply(ratio).setScale(2, RoundingMode.HALF_UP);
  }

  private BigDecimal money(BigDecimal amount) {
    if (amount == null) {
      return BigDecimal.ZERO;
    }
    return amount.setScale(2, RoundingMode.HALF_UP);
  }
}
