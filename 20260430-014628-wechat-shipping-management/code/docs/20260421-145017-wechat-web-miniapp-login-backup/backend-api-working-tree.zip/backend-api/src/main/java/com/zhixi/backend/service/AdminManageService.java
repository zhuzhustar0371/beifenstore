package com.zhixi.backend.service;

import com.zhixi.backend.common.BusinessException;
import com.zhixi.backend.dto.AdminPageResult;
import com.zhixi.backend.dto.AdminProductUpsertRequest;
import com.zhixi.backend.dto.AdminUserVO;
import com.zhixi.backend.mapper.InviteRelationMapper;
import com.zhixi.backend.mapper.OrderMapper;
import com.zhixi.backend.mapper.ProductMapper;
import com.zhixi.backend.mapper.ShippingRecordMapper;
import com.zhixi.backend.mapper.CashbackRecordMapper;
import com.zhixi.backend.mapper.UserMapper;
import com.zhixi.backend.mapper.UserWechatAuthMapper;
import com.zhixi.backend.model.CashbackRecord;
import com.zhixi.backend.model.InviteRelation;
import com.zhixi.backend.model.Order;
import com.zhixi.backend.model.Product;
import com.zhixi.backend.model.User;
import com.zhixi.backend.model.UserWechatAuth;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminManageService {
  private final UserMapper userMapper;
  private final ProductMapper productMapper;
  private final InviteRelationMapper inviteRelationMapper;
  private final OrderMapper orderMapper;
  private final CashbackRecordMapper cashbackRecordMapper;
  private final ShippingRecordMapper shippingRecordMapper;
  private final UserWechatAuthMapper userWechatAuthMapper;
  private final WechatPayService wechatPayService;

  public AdminManageService(
      UserMapper userMapper,
      ProductMapper productMapper,
      InviteRelationMapper inviteRelationMapper,
      OrderMapper orderMapper,
      CashbackRecordMapper cashbackRecordMapper,
      ShippingRecordMapper shippingRecordMapper,
      UserWechatAuthMapper userWechatAuthMapper,
      WechatPayService wechatPayService
  ) {
    this.userMapper = userMapper;
    this.productMapper = productMapper;
    this.inviteRelationMapper = inviteRelationMapper;
    this.orderMapper = orderMapper;
    this.cashbackRecordMapper = cashbackRecordMapper;
    this.shippingRecordMapper = shippingRecordMapper;
    this.userWechatAuthMapper = userWechatAuthMapper;
    this.wechatPayService = wechatPayService;
  }

  public List<User> listUsers() {
    return userMapper.findAll();
  }

  public AdminPageResult<AdminUserVO> pageUsers(String keyword, Integer status, Integer page, Integer size) {
    int safePage = safePage(page);
    int safeSize = safeSize(size);
    int offset = (safePage - 1) * safeSize;
    long total = userMapper.countByAdminQuery(keyword, status);
    List<User> records = userMapper.findByAdminQuery(keyword, status, offset, safeSize);
    List<AdminUserVO> result = records.stream().map(this::toAdminUserVO).collect(Collectors.toList());
    return new AdminPageResult<>(result, total, safePage, safeSize);
  }

  public List<Product> listProducts() {
    return productMapper.findAll();
  }

  public AdminPageResult<Product> pageProducts(String keyword, Boolean active, Integer page, Integer size) {
    int safePage = safePage(page);
    int safeSize = safeSize(size);
    int offset = (safePage - 1) * safeSize;
    long total = productMapper.countByAdminQuery(keyword, active);
    List<Product> records = productMapper.findByAdminQuery(keyword, active, offset, safeSize);
    return new AdminPageResult<>(records, total, safePage, safeSize);
  }

  public List<InviteRelation> listInvites() {
    return inviteRelationMapper.findAll();
  }

  public AdminPageResult<InviteRelation> pageInvites(Long inviterId, Long inviteeId, Boolean firstPaidOnly, Integer page, Integer size) {
    int safePage = safePage(page);
    int safeSize = safeSize(size);
    int offset = (safePage - 1) * safeSize;
    long total = inviteRelationMapper.countByAdminQuery(inviterId, inviteeId, firstPaidOnly);
    List<InviteRelation> records = inviteRelationMapper.findByAdminQuery(inviterId, inviteeId, firstPaidOnly, offset, safeSize);
    return new AdminPageResult<>(records, total, safePage, safeSize);
  }

  public AdminPageResult<Order> pageOrders(String status, Long userId, String keyword, Integer page, Integer size) {
    int safePage = safePage(page);
    int safeSize = safeSize(size);
    int offset = (safePage - 1) * safeSize;
    long total = orderMapper.countByAdminQuery(status, userId, keyword);
    List<Order> records = orderMapper.findByAdminQuery(status, userId, keyword, offset, safeSize);
    return new AdminPageResult<>(records, total, safePage, safeSize);
  }

  public AdminPageResult<CashbackRecord> pageCashbacks(Long userId, String type, String status, Integer page, Integer size) {
    int safePage = safePage(page);
    int safeSize = safeSize(size);
    int offset = (safePage - 1) * safeSize;
    long total = cashbackRecordMapper.countByAdminQuery(userId, type, status);
    List<CashbackRecord> records = cashbackRecordMapper.findByAdminQuery(userId, type, status, offset, safeSize);
    return new AdminPageResult<>(records, total, safePage, safeSize);
  }

  @Transactional
  public void updateProductStatus(Long productId, Boolean active) {
    Product product = productMapper.findById(productId);
    if (product == null) {
      throw new BusinessException("商品不存在");
    }
    productMapper.updateActive(productId, active);
  }

  @Transactional
  public Product createProduct(AdminProductUpsertRequest request) {
    Product product = new Product();
    product.setName(request.getName().trim());
    product.setPrice(request.getPrice());
    product.setDescription(request.getDescription());
    product.setImageUrl(request.getImageUrl());
    product.setActive(request.getActive());
    productMapper.insert(product);
    return productMapper.findById(product.getId());
  }

  @Transactional
  public Product updateProduct(Long productId, AdminProductUpsertRequest request) {
    Product current = productMapper.findById(productId);
    if (current == null) {
      throw new BusinessException("商品不存在");
    }
    current.setName(request.getName().trim());
    current.setPrice(request.getPrice());
    current.setDescription(request.getDescription());
    current.setImageUrl(request.getImageUrl());
    current.setActive(request.getActive());
    productMapper.update(current);
    return productMapper.findById(productId);
  }

  @Transactional
  public void deleteProduct(Long productId) {
    Product current = productMapper.findById(productId);
    if (current == null) {
      throw new BusinessException("商品不存在");
    }
    productMapper.deleteById(productId);
  }

  @Transactional
  public void updateUserStatus(Long userId, Integer status) {
    User user = userMapper.findById(userId);
    if (user == null) {
      throw new BusinessException("用户不存在");
    }
    userMapper.updateStatus(userId, status);
  }

  @Transactional
  public void shipOrder(Long orderId, String trackingNo) {
    Order order = orderMapper.findById(orderId);
    if (order == null) {
      throw new BusinessException("订单不存在");
    }
    int changed = orderMapper.markShipped(orderId, trackingNo);
    if (changed <= 0) {
      throw new BusinessException("当前订单状态不可发货");
    }
    int updatedShipping = shippingRecordMapper.updateByOrderId(orderId, trackingNo);
    if (updatedShipping <= 0) {
      shippingRecordMapper.insert(orderId, trackingNo);
    }
  }

  @Transactional
  public void refundOrder(Long orderId, String reason) {
    Order order = orderMapper.findById(orderId);
    if (order == null) {
      throw new BusinessException("订单不存在");
    }
    if (!"PAID".equals(order.getStatus()) && !"SHIPPED".equals(order.getStatus())) {
      throw new BusinessException("当前订单状态不可退款");
    }
    if ("WECHAT".equals(order.getPayType())) {
      com.wechat.pay.java.service.refund.model.Refund wxRefund = wechatPayService.refundOrder(order, reason);
      orderMapper.updateRefundStatus(orderId, "PROCESSING", wxRefund.getRefundId());
    } else {
      orderMapper.updateRefundStatus(orderId, "SUCCESS", "MANUAL");
    }
    // 注意：如果是全额退款，也可以把 order_status 改为 REFUNDED
    orderMapper.markShipped(orderId, "REFUNDED"); // 这里只是一个复用示例，实际上应该有个专门的 markRefunded 方法。我们假定不改变主状态或您需要的话可以补充。
  }

  @Transactional
  public void transferCashback(Long cashbackId) {
    CashbackRecord cb = cashbackRecordMapper.findById(cashbackId);
    if (cb == null) {
      throw new BusinessException("返现记录不存在");
    }
    if (!"PENDING".equals(cb.getStatus())) {
      throw new BusinessException("该笔佣金不处于待发状态");
    }
    User user = userMapper.findById(cb.getUserId());
    String openid = resolveCashbackOpenid(user);
    if (user == null || openid == null) {
      throw new BusinessException("该用户不存在或尚未绑定微信小程序，无法进行微信打款");
    }
    
    com.wechat.pay.java.service.transferbatch.model.InitiateBatchTransferResponse resp = wechatPayService.transferToWallet(cb, openid);
    
    cashbackRecordMapper.updateTransferInfo(
        cashbackId,
        "PROCESSING",
        cb.getOutBatchNo(),
        cb.getOutDetailNo(),
        resp.getBatchId(),
        java.time.LocalDateTime.now()
    );
  }

  public long todayUsers() {
    return userMapper.countToday();
  }

  public long todayOrders() {
    return orderMapper.countTodayOrders();
  }

  public long pendingShipments() {
    return orderMapper.countPendingShipments();
  }

  public double todayIncome() {
    Double value = orderMapper.todayPaidAmount();
    return value == null ? 0D : value;
  }

  public double todayCashback() {
    Double value = cashbackRecordMapper.todayAmount();
    return value == null ? 0D : value;
  }

  private String resolveCashbackOpenid(User user) {
    if (user == null) {
      return null;
    }
    if (user.getMiniappOpenid() != null && !user.getMiniappOpenid().isBlank()) {
      return user.getMiniappOpenid();
    }
    UserWechatAuth auth = userWechatAuthMapper.findByUserId(user.getId());
    if (auth == null || auth.getOpenid() == null || auth.getOpenid().isBlank()) {
      return null;
    }
    userMapper.updateMiniappOpenid(user.getId(), auth.getOpenid());
    user.setMiniappOpenid(auth.getOpenid());
    return auth.getOpenid();
  }

  private int safePage(Integer page) {
    return (page == null || page < 1) ? 1 : page;
  }

  private int safeSize(Integer size) {
    if (size == null || size < 1) {
      return 20;
    }
    return Math.min(size, 100);
  }

  private AdminUserVO toAdminUserVO(User user) {
    AdminUserVO vo = new AdminUserVO();
    vo.setId(user.getId());
    vo.setPhone(user.getPhone());
    vo.setNickname(user.getNickname());
    vo.setInviteCode(user.getInviteCode());
    vo.setInviterId(user.getInviterId());
    vo.setStatus(user.getStatus());
    vo.setCreatedAt(user.getCreatedAt());
    return vo;
  }
}
