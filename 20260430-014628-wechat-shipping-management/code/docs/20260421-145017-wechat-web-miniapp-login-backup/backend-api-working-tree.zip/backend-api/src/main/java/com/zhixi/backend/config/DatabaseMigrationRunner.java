package com.zhixi.backend.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DatabaseMigrationRunner implements CommandLineRunner {
  private static final Logger log = LoggerFactory.getLogger(DatabaseMigrationRunner.class);

  private final JdbcTemplate jdbcTemplate;

  public DatabaseMigrationRunner(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  @Override
  public void run(String... args) {
    ensureColumn(
        "users.miniapp_openid",
        "SELECT miniapp_openid FROM users LIMIT 1",
        "ALTER TABLE users ADD COLUMN miniapp_openid VARCHAR(128) NULL UNIQUE AFTER status"
    );

    ensureColumn(
        "orders.pay_type",
        "SELECT pay_type FROM orders LIMIT 1",
        "ALTER TABLE orders "
            + "ADD COLUMN pay_type VARCHAR(32) NULL, "
            + "ADD COLUMN transaction_id VARCHAR(64) NULL, "
            + "ADD COLUMN refund_status VARCHAR(32) NOT NULL DEFAULT 'NONE', "
            + "ADD COLUMN refund_id VARCHAR(64) NULL"
    );

    ensureColumn(
        "sms_login_codes.scene",
        "SELECT scene FROM sms_login_codes LIMIT 1",
        "ALTER TABLE sms_login_codes ADD COLUMN scene VARCHAR(32) NOT NULL DEFAULT 'REGISTER' AFTER code"
    );

    ensureColumn(
        "orders.order_no",
        "SELECT order_no FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN order_no VARCHAR(64) NULL"
    );
    ensureColumn(
        "user_wechat_auth.source_type",
        "SELECT source_type FROM user_wechat_auth LIMIT 1",
        "ALTER TABLE user_wechat_auth ADD COLUMN source_type VARCHAR(32) NOT NULL DEFAULT 'MINIAPP' AFTER user_id"
    );
    ensureColumn(
        "user_wechat_auth.updated_at",
        "SELECT updated_at FROM user_wechat_auth LIMIT 1",
        "ALTER TABLE user_wechat_auth ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP"
    );
    dropConstraintIfExists(
        "user_wechat_auth.user_id unique index",
        "ALTER TABLE user_wechat_auth DROP INDEX user_id"
    );
    dropConstraintIfExists(
        "user_wechat_auth.user_id unique constraint",
        "ALTER TABLE user_wechat_auth DROP CONSTRAINT user_id"
    );
    ensureColumn(
        "orders.order_status",
        "SELECT order_status FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN order_status VARCHAR(32) NOT NULL DEFAULT 'PENDING'"
    );
    ensureColumn(
        "orders.pay_amount",
        "SELECT pay_amount FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN pay_amount DECIMAL(10,2) NULL DEFAULT 0"
    );
    ensureColumn(
        "orders.remark",
        "SELECT remark FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN remark VARCHAR(255) NULL"
    );
    ensureColumn(
        "orders.updated_at",
        "SELECT updated_at FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP"
    );
    ensureColumn(
        "orders.pay_time",
        "SELECT pay_time FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN pay_time TIMESTAMP NULL"
    );
    ensureColumn(
        "orders.complete_time",
        "SELECT complete_time FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN complete_time TIMESTAMP NULL"
    );
    ensureColumn(
        "orders.product_id",
        "SELECT product_id FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN product_id BIGINT NULL"
    );
    ensureColumn(
        "orders.quantity",
        "SELECT quantity FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN quantity INT NOT NULL DEFAULT 1"
    );
    ensureColumn(
        "orders.recipient_name",
        "SELECT recipient_name FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN recipient_name VARCHAR(64) NULL"
    );
    ensureColumn(
        "orders.recipient_phone",
        "SELECT recipient_phone FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN recipient_phone VARCHAR(32) NULL"
    );
    ensureColumn(
        "orders.address",
        "SELECT address FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN address VARCHAR(255) NULL"
    );
    ensureColumn(
        "orders.tracking_no",
        "SELECT tracking_no FROM orders LIMIT 1",
        "ALTER TABLE orders ADD COLUMN tracking_no VARCHAR(64) NULL"
    );
    ensureColumn(
        "cashback_records.out_batch_no",
        "SELECT out_batch_no FROM cashback_records LIMIT 1",
        "ALTER TABLE cashback_records ADD COLUMN out_batch_no VARCHAR(64) NULL"
    );
    ensureColumn(
        "cashback_records.out_detail_no",
        "SELECT out_detail_no FROM cashback_records LIMIT 1",
        "ALTER TABLE cashback_records ADD COLUMN out_detail_no VARCHAR(64) NULL"
    );
    ensureColumn(
        "cashback_records.transfer_id",
        "SELECT transfer_id FROM cashback_records LIMIT 1",
        "ALTER TABLE cashback_records ADD COLUMN transfer_id VARCHAR(64) NULL"
    );
    ensureColumn(
        "cashback_records.transfer_time",
        "SELECT transfer_time FROM cashback_records LIMIT 1",
        "ALTER TABLE cashback_records ADD COLUMN transfer_time TIMESTAMP NULL"
    );

    syncLegacyOrderColumns();
  }

  private void ensureColumn(String label, String probeSql, String alterSql) {
    try {
      jdbcTemplate.execute(probeSql);
    } catch (Exception e) {
      log.info("Detected missing {}, applying migration.", label);
      try {
        jdbcTemplate.execute(alterSql);
        log.info("Migration for {} completed.", label);
      } catch (Exception ex) {
        log.error("Migration for {} failed.", label, ex);
      }
    }
  }

  private void dropConstraintIfExists(String label, String sql) {
    try {
      jdbcTemplate.execute(sql);
      log.info("Dropped {}.", label);
    } catch (Exception ignored) {
      // The index/constraint may not exist or may use a database-specific name.
    }
  }

  private void syncLegacyOrderColumns() {
    try {
      jdbcTemplate.update("UPDATE orders SET order_status = status WHERE order_status IS NULL AND status IS NOT NULL");
    } catch (Exception ignored) {
      // Skip when the old/new source column does not exist.
    }
    try {
      jdbcTemplate.update("UPDATE orders SET pay_time = paid_at WHERE pay_time IS NULL AND paid_at IS NOT NULL");
    } catch (Exception ignored) {
      // Skip when the old/new source column does not exist.
    }
    try {
      jdbcTemplate.update("UPDATE orders SET complete_time = completed_at WHERE complete_time IS NULL AND completed_at IS NOT NULL");
    } catch (Exception ignored) {
      // Skip when the old/new source column does not exist.
    }
    try {
      jdbcTemplate.update("UPDATE orders SET pay_amount = total_amount WHERE pay_amount IS NULL AND total_amount IS NOT NULL");
    } catch (Exception ignored) {
      // Skip when the old/new source column does not exist.
    }
    try {
      jdbcTemplate.update("UPDATE orders SET updated_at = created_at WHERE updated_at IS NULL AND created_at IS NOT NULL");
    } catch (Exception ignored) {
      // Skip when the old/new source column does not exist.
    }
    try {
      jdbcTemplate.update(
          "UPDATE orders SET order_no = CONCAT('ZX', DATE_FORMAT(created_at, '%Y%m%d%H%i%s'), LPAD(id, 4, '0')) "
              + "WHERE order_no IS NULL"
      );
    } catch (Exception ignored) {
      // Skip when the SQL dialect or columns are not compatible.
    }
  }
}
