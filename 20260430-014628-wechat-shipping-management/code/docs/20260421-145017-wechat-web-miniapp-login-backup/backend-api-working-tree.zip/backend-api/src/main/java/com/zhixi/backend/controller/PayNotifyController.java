package com.zhixi.backend.controller;

import com.wechat.pay.java.core.notification.NotificationConfig;
import com.wechat.pay.java.core.notification.NotificationParser;
import com.wechat.pay.java.core.notification.RequestParam;
import com.wechat.pay.java.service.payments.model.Transaction;
import com.zhixi.backend.model.Order;
import com.zhixi.backend.service.OrderService;
import com.zhixi.backend.service.WechatPayService;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/pay/wechat")
public class PayNotifyController {
  private static final Logger log = LoggerFactory.getLogger(PayNotifyController.class);

  private final WechatPayService wechatPayService;
  private final OrderService orderService;

  public PayNotifyController(WechatPayService wechatPayService, OrderService orderService) {
    this.wechatPayService = wechatPayService;
    this.orderService = orderService;
  }

  @PostMapping("/notify")
  public ResponseEntity<Map<String, String>> handleNotify(HttpServletRequest request) {
    try {
      String body = readBody(request);
      RequestParam requestParam = new RequestParam.Builder()
          .serialNumber(request.getHeader("Wechatpay-Serial"))
          .nonce(request.getHeader("Wechatpay-Nonce"))
          .signature(request.getHeader("Wechatpay-Signature"))
          .timestamp(request.getHeader("Wechatpay-Timestamp"))
          .body(body)
          .build();

      NotificationParser parser =
          new NotificationParser((NotificationConfig) wechatPayService.getConfig());
      Transaction transaction = parser.parse(requestParam, Transaction.class);

      log.info(
          "Received WeChat Pay callback, outTradeNo={}, transactionId={}, tradeState={}",
          transaction.getOutTradeNo(),
          transaction.getTransactionId(),
          transaction.getTradeState()
      );

      if (Transaction.TradeStateEnum.SUCCESS.equals(transaction.getTradeState())) {
        Order order = orderService.getOrderByOrderNo(transaction.getOutTradeNo());
        if ("PENDING".equals(order.getStatus())) {
          LocalDateTime paidAt = resolvePaidAt(transaction.getSuccessTime());
          orderService.markPaid(order.getId(), paidAt, "WECHAT", transaction.getTransactionId());
        } else {
          log.info("Skip duplicated callback for orderNo={}, status={}", order.getOrderNo(), order.getStatus());
        }
      }

      return ResponseEntity.ok(successBody());
    } catch (Exception e) {
      log.error("Failed to process WeChat Pay callback", e);
      Map<String, String> error = new HashMap<>();
      error.put("code", "FAIL");
      error.put("message", "failed");
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
  }

  private String readBody(HttpServletRequest request) throws java.io.IOException {
    BufferedReader reader = request.getReader();
    StringBuilder builder = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) {
      builder.append(line);
    }
    return builder.toString();
  }

  private LocalDateTime resolvePaidAt(String successTime) {
    if (successTime == null || successTime.isBlank()) {
      return LocalDateTime.now();
    }
    return OffsetDateTime.parse(successTime).toLocalDateTime();
  }

  private Map<String, String> successBody() {
    Map<String, String> response = new HashMap<>();
    response.put("code", "SUCCESS");
    response.put("message", "success");
    return response;
  }
}
