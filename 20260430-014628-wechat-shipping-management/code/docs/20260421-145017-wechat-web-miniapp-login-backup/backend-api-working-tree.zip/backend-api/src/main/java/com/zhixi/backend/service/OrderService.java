package com.zhixi.backend.service;

import com.zhixi.backend.common.BusinessException;
import com.zhixi.backend.dto.CreateOrderRequest;
import com.zhixi.backend.mapper.InviteRelationMapper;
import com.zhixi.backend.mapper.OrderMapper;
import com.zhixi.backend.model.Order;
import com.zhixi.backend.model.Product;
import com.zhixi.backend.model.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {
  private final OrderMapper orderMapper;
  private final UserService userService;
  private final ProductService productService;
  private final InviteRelationMapper inviteRelationMapper;
  private final CashbackService cashbackService;

  public OrderService(
      OrderMapper orderMapper,
      UserService userService,
      ProductService productService,
      InviteRelationMapper inviteRelationMapper,
      CashbackService cashbackService
  ) {
    this.orderMapper = orderMapper;
    this.userService = userService;
    this.productService = productService;
    this.inviteRelationMapper = inviteRelationMapper;
    this.cashbackService = cashbackService;
  }

  @Transactional
  public Order createOrder(Long userId, CreateOrderRequest request) {
    userService.getUser(userId);
    Product product = productService.getById(request.getProductId());

    Order order = new Order();
    order.setUserId(userId);
    order.setProductId(request.getProductId());
    order.setQuantity(request.getQuantity());
    order.setRecipientName(request.getRecipientName());
    order.setRecipientPhone(request.getRecipientPhone());
    order.setAddress(request.getAddress());
    order.setStatus("PENDING");
    order.setTotalAmount(product.getPrice().multiply(BigDecimal.valueOf(request.getQuantity())));
    orderMapper.insert(order);
    return orderMapper.findById(order.getId());
  }

  @Transactional
  public Order markPaid(Long orderId) {
    return markPaid(orderId, LocalDateTime.now(), "MOCK", "MOCK_" + System.currentTimeMillis());
  }

  @Transactional
  public Order markPaid(Long orderId, LocalDateTime paidAt, String paymentMethod, String transactionId) {
    Order current = getOrder(orderId);
    if (isAlreadyPaid(current) && transactionId != null && transactionId.equals(current.getTransactionId())) {
      return current;
    }
    if (!"PENDING".equals(current.getStatus())) {
      throw new BusinessException("仅待支付订单可支付");
    }

    int updated = orderMapper.markPaid(orderId, paidAt, paymentMethod, transactionId);
    if (updated <= 0) {
      throw new BusinessException("订单支付状态更新失败");
    }

    Order order = orderMapper.findById(orderId);
    int paidBefore = orderMapper.countPaidBeforeOrder(order.getUserId(), order.getId());
    int paidSeq = paidBefore + 1;
    cashbackService.grantPersonalCashback(order.getUserId(), order.getId(), paidSeq, order.getTotalAmount());

    int firstPaidMarked = inviteRelationMapper.markFirstPaid(order.getUserId(), paidAt);
    if (firstPaidMarked > 0) {
      User user = userService.getUser(order.getUserId());
      if (user.getInviterId() != null) {
        int firstPaidCount = inviteRelationMapper.countInviteeFirstPaid(user.getInviterId());
        cashbackService.grantInviteBatchCashback(user.getInviterId(), firstPaidCount, order.getTotalAmount());
      }
    }

    return order;
  }

  public List<Order> listByUser(Long userId) {
    userService.getUser(userId);
    return orderMapper.findByUserId(userId);
  }

  public List<Order> listAll() {
    return orderMapper.findAll();
  }

  public double totalPaidAmount() {
    Double value = orderMapper.totalPaidAmount();
    return value == null ? 0D : value;
  }

  public Order getOrder(Long orderId) {
    Order order = orderMapper.findById(orderId);
    if (order == null) {
      throw new BusinessException("订单不存在");
    }
    return order;
  }

  public Order getOrderByOrderNo(String orderNo) {
    Order order = orderMapper.findByOrderNo(orderNo);
    if (order == null) {
      throw new BusinessException("订单不存在");
    }
    return order;
  }

  public Order getOrderForUser(Long orderId, Long userId) {
    Order order = getOrder(orderId);
    if (!order.getUserId().equals(userId)) {
      throw new BusinessException("订单不存在");
    }
    return order;
  }

  private boolean isAlreadyPaid(Order order) {
    String status = order.getStatus();
    return "PAID".equals(status) || "SHIPPED".equals(status) || "COMPLETED".equals(status);
  }
}
