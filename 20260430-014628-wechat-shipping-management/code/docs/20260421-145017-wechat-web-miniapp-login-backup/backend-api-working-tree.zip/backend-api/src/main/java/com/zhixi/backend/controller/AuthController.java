package com.zhixi.backend.controller;

import com.zhixi.backend.common.ApiResponse;
import com.zhixi.backend.dto.PasswordLoginRequest;
import com.zhixi.backend.dto.RegisterRequest;
import com.zhixi.backend.dto.ResetPasswordRequest;
import com.zhixi.backend.dto.SmsLoginRequest;
import com.zhixi.backend.dto.SmsSendRequest;
import com.zhixi.backend.dto.WechatBindMobileRequest;
import com.zhixi.backend.dto.WechatMiniappLoginRequest;
import com.zhixi.backend.dto.WechatMockScanRequest;
import com.zhixi.backend.model.User;
import com.zhixi.backend.service.UserAuthService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
  private final UserAuthService userAuthService;

  public AuthController(UserAuthService userAuthService) {
    this.userAuthService = userAuthService;
  }

  @PostMapping("/register")
  public ApiResponse<Map<String, Object>> register(@Valid @RequestBody RegisterRequest request) {
    return ApiResponse.ok(userAuthService.registerUser(request));
  }

  @PostMapping("/login")
  public ApiResponse<Map<String, Object>> loginByPassword(@Valid @RequestBody PasswordLoginRequest request) {
    return ApiResponse.ok(userAuthService.loginByPassword(request));
  }

  @PostMapping("/wechat-miniapp/login")
  public ApiResponse<Map<String, Object>> loginByMiniapp(@Valid @RequestBody WechatMiniappLoginRequest request) {
    return ApiResponse.ok(userAuthService.loginByMiniapp(request));
  }

  @PostMapping("/sms/send")
  public ApiResponse<Map<String, Object>> sendSms(@Valid @RequestBody SmsSendRequest request) {
    return ApiResponse.ok(userAuthService.sendSmsCode(request.getPhone(), request.getScene()));
  }

  @PostMapping("/sms/login")
  public ApiResponse<Map<String, Object>> loginBySms(@Valid @RequestBody SmsLoginRequest request) {
    return ApiResponse.ok(userAuthService.loginBySms(request));
  }

  @PostMapping("/password/reset")
  public ApiResponse<Map<String, Object>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
    return ApiResponse.ok(userAuthService.resetPassword(request));
  }

  @PostMapping("/wechat/qr/create")
  public ApiResponse<Map<String, Object>> createWechatQr() {
    return ApiResponse.ok(userAuthService.createWechatQrSession());
  }

  @GetMapping("/wechat/qr/status/{scene}")
  public ApiResponse<Map<String, Object>> queryQrStatus(@PathVariable String scene) {
    return ApiResponse.ok(userAuthService.queryWechatQrStatus(scene));
  }

  @PostMapping("/wechat/mock-scan")
  public ApiResponse<Void> mockScan(@Valid @RequestBody WechatMockScanRequest request) {
    userAuthService.mockScanWechat(request.getScene(), request.getOpenid(), request.getNickname());
    return ApiResponse.ok(null);
  }

  @PostMapping("/wechat/bind-mobile")
  public ApiResponse<Map<String, Object>> bindWechatMobile(@Valid @RequestBody WechatBindMobileRequest request) {
    return ApiResponse.ok(userAuthService.bindWechatMobile(request));
  }

  @GetMapping(value = "/wechat/callback", produces = MediaType.TEXT_HTML_VALUE)
  public ResponseEntity<String> wechatCallback(
      @RequestParam String code,
      @RequestParam(name = "state", required = false) String scene
  ) {
    try {
      userAuthService.handleWechatWebCallback(code, scene);
      return ResponseEntity.ok(wechatCallbackHtml("微信登录成功", "请返回原页面继续使用。"));
    } catch (Exception ex) {
      return ResponseEntity.badRequest().body(wechatCallbackHtml("微信登录失败", ex.getMessage()));
    }
  }

  @GetMapping("/me")
  public ApiResponse<Map<String, Object>> me(@RequestHeader(value = "Authorization", required = false) String authorization) {
    User user = userAuthService.getUserByToken(extractToken(authorization));
    Map<String, Object> data = new HashMap<>();
    data.put("id", user.getId());
    data.put("userId", user.getId());
    data.put("phone", publicPhone(user.getPhone()));
    data.put("nickname", user.getNickname());
    data.put("inviteCode", user.getInviteCode());
    return ApiResponse.ok(data);
  }

  @PostMapping("/logout")
  public ApiResponse<Void> logout(@RequestHeader(value = "Authorization", required = false) String authorization) {
    userAuthService.logout(extractToken(authorization));
    return ApiResponse.ok(null);
  }

  private String extractToken(String authorization) {
    if (authorization == null || authorization.isBlank()) {
      return "";
    }
    String prefix = "Bearer ";
    return authorization.startsWith(prefix) ? authorization.substring(prefix.length()).trim() : authorization.trim();
  }

  private String wechatCallbackHtml(String title, String message) {
    return "<!doctype html><html><head><meta charset=\"utf-8\"><title>"
        + escapeHtml(title)
        + "</title><style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
        + "display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;color:#1f2937}"
        + ".box{text-align:center;line-height:1.7}.title{font-size:22px;font-weight:700}.msg{color:#6b7280}</style>"
        + "</head><body><div class=\"box\"><div class=\"title\">"
        + escapeHtml(title)
        + "</div><div class=\"msg\">"
        + escapeHtml(message)
        + "</div></div></body></html>";
  }

  private String escapeHtml(String value) {
    if (value == null) {
      return "";
    }
    return value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;");
  }

  private String publicPhone(String phone) {
    if (phone == null) {
      return "";
    }
    if (phone.startsWith("wxmp_") || phone.startsWith("wxweb_")) {
      return "";
    }
    return phone;
  }
}
